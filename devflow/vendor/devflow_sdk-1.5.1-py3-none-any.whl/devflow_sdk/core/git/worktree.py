# devflow_sdk/core/git/worktree.py
import json
import os
import subprocess
import sys

from devflow_sdk.core.prompts import confirm, select, Choice


def _git_toplevel(path: str) -> str | None:
    """Return the git repository root for the given path, or None on failure."""
    result = subprocess.run(
        ["git", "-C", path, "rev-parse", "--show-toplevel"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return None
    return result.stdout.strip()


def _cwd_inside_worktree(worktree_path, cwd=None):
    """Return True if cwd (defaults to os.getcwd()) is at or inside worktree_path."""
    cwd = os.path.realpath(cwd if cwd is not None else os.getcwd())
    worktree_path = os.path.realpath(worktree_path)
    return cwd == worktree_path or cwd.startswith(worktree_path + os.sep)


def _normalize_wt_items(data: object) -> list:
    """Normalize wt list --format json output to a flat list of {branch, path, is_main} dicts.

    Handles both the legacy flat-list format and the schema-2 dict format
    introduced in a later wt release.
    """
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and "items" in data:
        normalized = []
        for item in data["items"]:
            wt = item.get("worktree", {})
            normalized.append({
                "branch": item.get("branch"),
                "path": wt.get("path"),
                "is_main": bool(wt.get("main")),
            })
        return normalized
    return []


def query_worktrees() -> list | None:
    """Return parsed wt list --format json output, or None on any failure."""
    try:
        result = subprocess.run(
            ["wt", "list", "--format", "json"],
            capture_output=True, text=True,
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    try:
        return _normalize_wt_items(json.loads(result.stdout))
    except json.JSONDecodeError:
        return None


def list_worktrees() -> list:
    """Return the parsed wt list --format json payload, or exit 1 on failure."""
    from devflow_sdk.core.git._worktrunk import WORKTRUNK_INSTALL_HINT
    try:
        result = subprocess.run(
            ["wt", "list", "--format", "json"],
            capture_output=True, text=True,
        )
    except FileNotFoundError:
        print(WORKTRUNK_INSTALL_HINT, file=sys.stderr)
        sys.exit(1)
    if result.returncode != 0:
        print(f"ERROR: 'wt list' failed:\n{result.stderr}", file=sys.stderr)
        sys.exit(1)
    try:
        return _normalize_wt_items(json.loads(result.stdout))
    except json.JSONDecodeError:
        print(f"ERROR: 'wt list' returned invalid JSON:\n{result.stdout}", file=sys.stderr)
        sys.exit(1)


def is_dirty(path: str) -> bool:
    """Return True if the worktree at path has uncommitted changes."""
    try:
        result = subprocess.run(
            ["git", "-C", path, "status", "--porcelain"],
            capture_output=True, text=True,
        )
    except OSError:
        return False
    return bool(result.stdout.strip())


def get_repo_root() -> str:
    """Return the root of the main worktree (not necessarily cwd)."""
    worktrees = query_worktrees()
    if worktrees is not None:
        for wt in worktrees:
            if wt.get("is_main"):
                return wt["path"]

    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        print("ERROR: Not inside a git repository.", file=sys.stderr)
        sys.exit(1)
    return result.stdout.strip()


def _find_worktree_path(branch: str) -> str | None:
    worktrees = query_worktrees()
    if worktrees is None:
        return None
    for wt in worktrees:
        if wt.get("branch") == branch:
            return wt.get("path")
    return None


def _detect_incoming_commits(branch: str) -> None:
    subprocess.run(
        ["git", "fetch", "origin", branch],
        capture_output=True, text=True,
    )
    result = subprocess.run(
        ["git", "rev-list", "--count", f"{branch}..origin/{branch}"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return
    try:
        count = int(result.stdout.strip())
    except ValueError:
        return
    if count == 0:
        return
    print(f"Remote has {count} commit(s) that '{branch}' does not have.")
    choice = select(
        "What would you like to do?",
        choices=[
            Choice("Pull latest changes", value="pull"),
            Choice("Continue without pulling", value="skip"),
        ],
        single=True,
    )
    if choice == "pull":
        subprocess.run(
            ["git", "fetch", "origin", f"{branch}:{branch}"],
            capture_output=True, text=True,
        )


def _branch_exists_locally(branch: str) -> bool:
    result = subprocess.run(
        ["git", "branch", "--list", branch],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        print(f"ERROR: git branch --list failed: {result.stderr.strip()}", file=sys.stderr)
        sys.exit(1)
    return bool(result.stdout.strip())


def create_worktree(branch: str, *, base: str | None = None) -> str | None:
    """Create or switch to a worktree for branch. Returns the worktree path."""
    if _branch_exists_locally(branch):
        _detect_incoming_commits(branch)
        print(f"Branch '{branch}' already exists.")
        if not confirm(f"Switch to existing branch '{branch}'?"):
            print("Aborted.")
            sys.exit(0)
        print(f"Switching to worktree for '{branch}'...")
        result = subprocess.run(["wt", "switch", "--no-cd", branch], text=True)
        if result.returncode != 0:
            sys.exit(1)
        return _find_worktree_path(branch)

    print(f"Creating worktree for '{branch}' (pre-start hooks may take a few minutes)...")
    cmd = ["wt", "switch", "--create", "--no-cd"]
    if base:
        cmd += ["--base", base]
    cmd.append(branch)
    result = subprocess.run(cmd, text=True)
    if result.returncode != 0:
        sys.exit(1)
    return _find_worktree_path(branch)
